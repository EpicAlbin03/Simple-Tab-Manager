import{a as t}from"../chunks/entry.DOUY1Qbx.js";export{t as start};
