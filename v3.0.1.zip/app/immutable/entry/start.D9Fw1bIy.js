import{a as t}from"../chunks/entry.B8IQ4r-1.js";export{t as start};
