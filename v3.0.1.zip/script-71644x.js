
				{
					__sveltekit_vrqdeb = {
						base: new URL(".", location).pathname.slice(0, -1)
					};

					const element = document.currentScript.parentElement;

					const data = [null,null];

					Promise.all([
						import("./app/immutable/entry/start.DaxNvJ0Z.js"),
						import("./app/immutable/entry/app.CGovI8sA.js")
					]).then(([kit, app]) => {
						kit.start(app, element, {
							node_ids: [0, 2],
							data,
							form: null,
							error: null
						});
					});

					if ('serviceWorker' in navigator) {
						addEventListener('load', function () {
							navigator.serviceWorker.register('./service-worker.js');
						});
					}
				}
			